
package figura2;

/**
 *
 * @author Luisa A
 */
public class  Cuadrado {
    //atributos
    private double area;
    private double perimetro;
    private double lado;
    
    //Constructor
    public Cuadrado(double Lado)
    {
        this.lado = Lado;
    }
    //Metodos
    public double getLado()
    {
        return lado;
    }
    
    //Calcular el area con el lado pedido
    public double CalcularArea()
    {
        area = lado * lado;
        return area;
    }
    
    //Calcular el perimetro con el lado pedido
    public double CalcularPerimetro()
    {
        perimetro = lado * 4;
        return perimetro;
    }

    
    public void Imprimir()
    {
        System.out.println("el area es: " + CalcularArea());
        System.out.println("el perimetro es: " + CalcularPerimetro());
    }
}
