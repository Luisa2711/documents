
package figura2;

import java.io.PrintStream;
import java.util.Scanner;

/**
 *
 * @author Luisa A
 */
public class Figura2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner leer = new Scanner(System.in);
        
        //llamamos y utlizamos el objeto
        System.out.println("Ingrese el lado del cuadrado");
        double l = leer.nextDouble();
        Cuadrado cua = new Cuadrado(l);
   
        cua.Imprimir();
    }
    
}
