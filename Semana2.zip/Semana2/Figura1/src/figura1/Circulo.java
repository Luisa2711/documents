
package figura1;

/**
 *
 * @author Luisa A
 */
public class Circulo {
    //atributos
    private double radio;
    private double area;
    private double perimetro;
    
    static double pi = 3.14;
    
    //Metodos
    public Circulo(double Radio)
    {
        this.radio = Radio;
    }
    
    public double getRadio()
    {
        return radio;
    }
    
    public double CalcularArea()
    {
        area = radio * radio * pi;
        return area;
    }
    
    public double CalcularPerimetro()
    {
        perimetro = 2 * pi * radio;
        return perimetro;
    }
    
    public void Imprimir()
    {
        System.out.println("el area es: " + CalcularArea());
        System.out.println("el perimetro es: " + CalcularPerimetro());
    }
}
