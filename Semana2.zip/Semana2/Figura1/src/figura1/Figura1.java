
package figura1;import java.util.Scanner;

public class Figura1 {

   
    public static void main(String[] args) {
        
        //Instanciamos la clase circulo
        
        Scanner leer = new Scanner(System.in);
        
        //llamamos y utlizamos el objeto
        System.out.println("Ingrese el radio del circulo");
        double r = leer.nextDouble();
        Circulo cir = new Circulo(r);
        
        cir.Imprimir();
    }
    
}
