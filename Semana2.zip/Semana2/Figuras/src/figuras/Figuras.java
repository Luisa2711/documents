
package figuras;
import java.util.Scanner;
import java.util.InputMismatchException;

/**
 *
 * @author Luisa A
 */
public class Figuras {
    public static void main(String[] args) {
        Scanner sn = new Scanner(System.in);
        boolean salir = false;
        int opcion;
       
        while(!salir){
            System.out.println("Bienvenido al programa figuras");
            System.out.println("Menu");
            System.out.println("1.Circulo");
            System.out.println("2.Cuadrado");
            System.out.println("3.Triangulo");
            System.out.println("4.Exit");
            
            try {
                System.out.println("Elige una opcion correcta");
                opcion = sn.nextInt();
                
                    switch (opcion) {
                    case 1:
                        System.out.println("Has seleccionado la opcion 1, Circulo");
                        System.out.println("Ingrese el radio del circulo");
                        double r = sn.nextDouble();
                        Circulo cir = new Circulo(r);
        
                        cir.Imprimir();
                        System.out.println("----------------------");
                        break;
                    case 2:
                        System.out.println("Has seleccionado la opcion 2, Cuadrado");
                        System.out.println("Ingrese el lado del cuadrado");
                        double l = sn.nextDouble();
                        Cuadrado cua = new Cuadrado(l);

                        cua.Imprimir();
                        System.out.println("----------------------");
                        break;
                    case 3:
                        System.out.println("Has seleccionado la opcion 3, Triangulo");
                        System.out.println("Ingrese la base del triangulo");
                        double b = sn.nextDouble();
                        System.out.println("Ingrese la altura del triangulo");
                        double a = sn.nextDouble();
                        System.out.println("Ingrese el lado del triangulo");
                        double la = sn.nextDouble();
                        Triangulo tri = new Triangulo(b,a,la);
   
                        tri.Imprimir();
                        
                        System.out.println("----------------------");
                        break;
                    case 4:
                        salir = true;
                        break;
                    default:
                        System.out.println("Solo números entre 1 y 4");
                    }
                    
            } catch (InputMismatchException e) {
                System.out.println("Debes insertar un número");
                sn.next();
            }
        }
        
    }
    
}
