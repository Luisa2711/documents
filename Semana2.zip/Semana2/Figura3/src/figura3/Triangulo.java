
package figura3;

/**
 *
 * @author Luisa A
 */
public class Triangulo {
   
    private double base;
    private double altura;
    private double area;
    private double perimetro;
    private double lado;
    
    public Triangulo(double Base, double Altura, double Lado) 
    {
        this.base = Base;
        this.altura = Altura;
        this.lado = Lado;
    }
 
    public double getBase() 
    {
        return base;
    }
 
    public double getAltura() 
    {
        return altura;
    }
 
    public double CalcularArea() 
    {
        area = base * altura / 2;
        return area;
    }    
    
    public double CalcularPerimetro() 
    {
        perimetro = base + altura + lado;
        return perimetro;
    }    
    
    
    public void Imprimir()
    {
        System.out.println("el area es: " + CalcularArea());
        System.out.println("el perimetro es: " + CalcularPerimetro());
    }
    
}
