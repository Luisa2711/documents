
package figura3;

import java.util.Scanner;

/**
 *
 * @author Luisa A
 */
public class Figura3 {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        
        //llamamos y utlizamos el objeto
        System.out.println("Ingrese la base del triangulo");
        double b = leer.nextDouble();
        System.out.println("Ingrese la altura del triangulo");
        double a = leer.nextDouble();
        System.out.println("Ingrese el lado del triangulo");
        double l = leer.nextDouble();
        Triangulo tri = new Triangulo(b,a,l);
   
        tri.Imprimir();
    }
    
}
